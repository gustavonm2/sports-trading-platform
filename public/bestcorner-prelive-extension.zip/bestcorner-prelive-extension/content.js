/**
 * BestCorner Pré-Live Extension — Content Script v3
 * Abordagem de varredura sequencial global: coleta TODOS os nós de texto folha
 * do DOM em ordem de leitura e localiza padrões de partida (VS, x, ×).
 * Suporta: Técnica Limite HT/FT, Destaques TOP 10, Média de Escanteios.
 */
(function () {
  const SUPABASE_URL = 'https://kpldcqujhpcihpdlzpeh.supabase.co';
  const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImtwbGRjcXVqaHBjaWhwZGx6cGVoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODAxNTIyMTAsImV4cCI6MjA5NTcyODIxMH0.zfpSeKGm-RF0bvbj-H-yVm4it9qZNzBOX7KjrjieGfs';

  let scannedData = [];

  // ═══════════════════════════════════════════════════════════════════
  // PAINEL FLUTUANTE
  // ═══════════════════════════════════════════════════════════════════
  function injectPanel() {
    if (document.getElementById('tradepro-prelive-panel')) return;

    const panel = document.createElement('div');
    panel.id = 'tradepro-prelive-panel';
    panel.style.cssText = `
      position: fixed; bottom: 20px; right: 20px; z-index: 999999;
      background: rgba(15, 23, 42, 0.94); backdrop-filter: blur(14px);
      -webkit-backdrop-filter: blur(14px);
      border: 1px solid rgba(255,255,255,0.15); border-radius: 12px;
      box-shadow: 0 10px 40px rgba(0,0,0,0.6); color: #f1f5f9;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      width: 340px; overflow: hidden;
      transition: all 0.3s cubic-bezier(0.4,0,0.2,1);
    `;

    const todayStr = new Date().toISOString().split('T')[0];
    panel.innerHTML = `
      <div id="tradepro-panel-header" style="padding:12px 16px; background:rgba(30,41,59,0.8); border-bottom:1px solid rgba(255,255,255,0.12); display:flex; justify-content:space-between; align-items:center; cursor:pointer; user-select:none;">
        <span style="font-weight:700; font-size:0.9rem; display:flex; align-items:center; gap:8px;">📊 TradePro Pré-Live v3</span>
        <span id="tradepro-panel-toggle" style="font-size:0.75rem; color:#94a3b8; font-weight:500;">[Minimizar]</span>
      </div>
      <div id="tradepro-panel-body" style="padding:16px; display:flex; flex-direction:column; gap:14px;">
        <div>
          <label style="display:block; font-size:0.7rem; text-transform:uppercase; letter-spacing:0.05em; color:#94a3b8; margin-bottom:5px; font-weight:600;">Data de Referência</label>
          <input type="date" id="tradepro-sync-date" value="${todayStr}" style="width:100%; padding:8px 10px; border-radius:6px; border:1px solid rgba(255,255,255,0.15); background:rgba(30,41,59,0.8); color:#fff; font-size:0.85rem; box-sizing:border-box; outline:none;" />
        </div>
        <button id="tradepro-btn-scan" style="width:100%; padding:10px; border-radius:6px; border:none; background:#3b82f6; color:#fff; font-weight:700; cursor:pointer; font-size:0.8rem; box-shadow:0 4px 12px rgba(59,130,246,0.25);">
          🔍 Escanear Dados na Página
        </button>
        <div id="tradepro-scan-status" style="font-size:0.78rem; color:#cbd5e1; background:rgba(30,41,59,0.4); padding:10px; border-radius:6px; border:1px solid rgba(255,255,255,0.05); min-height:48px; display:flex; align-items:center; justify-content:center; text-align:center; line-height:1.4;">
          Abra qualquer página de estatísticas do BCS e clique em Escanear.
        </div>
        <button id="tradepro-btn-sync" disabled style="width:100%; padding:10px; border-radius:6px; border:none; background:#10b981; color:#fff; font-weight:700; cursor:not-allowed; opacity:0.4; font-size:0.8rem; box-shadow:0 4px 12px rgba(16,185,129,0.15);">
          🟢 Sincronizar com TradePro
        </button>
      </div>
    `;

    document.body.appendChild(panel);

    const header = document.getElementById('tradepro-panel-header');
    const body = document.getElementById('tradepro-panel-body');
    const toggle = document.getElementById('tradepro-panel-toggle');
    let minimized = false;

    header.addEventListener('click', () => {
      minimized = !minimized;
      body.style.display = minimized ? 'none' : 'flex';
      panel.style.width = minimized ? '200px' : '340px';
      toggle.textContent = minimized ? '[Maximizar]' : '[Minimizar]';
    });

    document.getElementById('tradepro-btn-scan').addEventListener('click', handleScan);
    document.getElementById('tradepro-btn-sync').addEventListener('click', handleSync);
  }

  // ═══════════════════════════════════════════════════════════════════
  // UTILIDADES
  // ═══════════════════════════════════════════════════════════════════
  function cleanTeamName(name) {
    if (!name) return '';
    return name
      .replace(/[\n\r]/g, ' ')
      .replace(/\s+/g, ' ')
      .replace(/[^a-zA-Z0-9\sÁÉÍÓÚáéíóúÂÊÔâêôÀàãõçÃÕñÑ\-\.\']/g, '')
      .trim();
  }

  function parseNum(str) {
    if (!str) return null;
    const m = str.replace('%', '').trim().replace(',', '.').match(/[\d.]+/);
    return m ? parseFloat(m[0]) : null;
  }

  function isNumericish(str) {
    return /^[\d.,]+%?$/.test(str.trim());
  }

  function isValidTeamName(text) {
    if (!text) return false;
    const clean = text.trim();
    if (clean.length < 2 || clean.length > 60) return false;
    if (/^[\d.,]+%?$/.test(clean)) return false;
    if (clean.includes('|') || clean.includes(':')) return false;
    const lower = clean.toLowerCase();
    const banned = [
      'vs', 'x', 'limite', 'casa', 'visitante', 'média', 'media',
      'classificação', 'detalhes', 'voltar', 'ordenar', 'buscar',
      'destaque', 'top 10', 'melhores', 'estatísticas', 'técnica',
      'tecnica', 'carregar', 'ver mais', 'best corner stats',
      'filtros', 'ordenação', 'partidas', 'destaques'
    ];
    if (banned.some(b => lower === b)) return false;
    return true;
  }

  // ═══════════════════════════════════════════════════════════════════
  // VARREDURA SEQUENCIAL GLOBAL — coração do scraper
  // ═══════════════════════════════════════════════════════════════════

  /**
   * Percorre todo o DOM e coleta TODOS os nós de texto folha na ordem
   * de leitura visual (depth-first, left-to-right).
   * Pula nosso próprio painel injetado.
   */
  function collectAllLeafTexts() {
    const leaves = [];
    function walk(node) {
      if (!node) return;
      const tag = node.tagName;
      if (tag === 'SCRIPT' || tag === 'STYLE' || tag === 'NOSCRIPT' || tag === 'SVG') return;
      if (node.id === 'tradepro-prelive-panel') return;

      if (node.children.length === 0) {
        const txt = (node.textContent || '').trim();
        if (txt.length > 0) {
          leaves.push(txt);
        }
      } else {
        for (let i = 0; i < node.children.length; i++) {
          walk(node.children[i]);
        }
      }
    }
    walk(document.body);
    return leaves;
  }

  /**
   * Detecta o modo da página (HT, FT ou ambos) com base no conteúdo.
   */
  function detectPagePeriods() {
    const bodyText = document.body.textContent || '';
    const url = window.location.href.toLowerCase();
    const hasHT = bodyText.includes('Limite HT') || bodyText.includes('Média HT') || url.includes('ht');
    const hasFT = bodyText.includes('Limite FT') || bodyText.includes('Média FT') || url.includes('ft');
    // Se nenhum detectado, assume FT (padrão mais comum)
    if (!hasHT && !hasFT) return { hasHT: false, hasFT: true };
    return { hasHT, hasFT };
  }

  /**
   * Localiza os índices de seções HT e FT na sequência de folhas,
   * para determinar a que seção cada partida pertence.
   */
  function findSectionBoundaries(leaves) {
    let htStart = -1;
    let ftStart = -1;
    leaves.forEach((txt, i) => {
      const lower = txt.toLowerCase();
      if ((lower.includes('técnica limite ht') || lower.includes('limite ht') || lower.includes('média ht')) && htStart === -1) {
        htStart = i;
      }
      if ((lower.includes('técnica limite ft') || lower.includes('limite ft') || lower.includes('média ft')) && ftStart === -1) {
        ftStart = i;
      }
    });
    return { htStart, ftStart };
  }

  /**
   * Dado um índice de separador e os limites de seção, determina se é HT ou FT.
   */
  function classifyPeriod(sepIndex, sections, pagePeriods) {
    const { htStart, ftStart } = sections;

    // Se ambas as seções existem na página, classificar pela posição
    if (htStart >= 0 && ftStart >= 0) {
      if (htStart < ftStart) {
        // HT vem antes de FT
        return sepIndex < ftStart ? 'HT' : 'FT';
      } else {
        // FT vem antes de HT
        return sepIndex < htStart ? 'FT' : 'HT';
      }
    }

    // Se só uma seção existe
    if (htStart >= 0) return 'HT';
    if (ftStart >= 0) return 'FT';

    // Fallback pelo modo geral da página
    if (pagePeriods.hasHT && !pagePeriods.hasFT) return 'HT';
    return 'FT';
  }

  /**
   * PARSER PRINCIPAL — extrai todos os jogos da página.
   */
  function scanPage() {
    const leaves = collectAllLeafTexts();
    const pagePeriods = detectPagePeriods();
    const sections = findSectionBoundaries(leaves);

    console.log(`[TradePro v3] ${leaves.length} nós folha coletados.`);
    console.log(`[TradePro v3] Períodos: HT=${pagePeriods.hasHT}, FT=${pagePeriods.hasFT}`);
    console.log(`[TradePro v3] Seções: htStart=${sections.htStart}, ftStart=${sections.ftStart}`);
    console.log(`[TradePro v3] Amostra (0-40):`, leaves.slice(0, 40));

    // Encontrar TODOS os separadores de partida
    const separators = []; // { index, type: 'standalone'|'inline' }

    leaves.forEach((txt, i) => {
      const upper = txt.toUpperCase().trim();
      // Separadores autônomos: texto é exatamente "VS", "X" ou "×"
      if (upper === 'VS' || upper === 'X' || upper === '×') {
        separators.push({ index: i, type: 'standalone' });
      }
      // Separadores inline: "Team A x Team B" com espaço ao redor
      else if (txt.length > 5 && /\s+(x|×|vs)\s+/i.test(txt)) {
        separators.push({ index: i, type: 'inline' });
      }
    });

    console.log(`[TradePro v3] ${separators.length} separadores encontrados (${separators.filter(s=>s.type==='standalone').length} standalone, ${separators.filter(s=>s.type==='inline').length} inline).`);

    const results = [];

    separators.forEach((sep, idx) => {
      try {
        let homeTeam = '';
        let awayTeam = '';
        let league = '';
        let dateStr = '';
        let timeStr = '';
        let stats = []; // valores numéricos após o separador
        let rate = null; // porcentagem para destaques

        if (sep.type === 'standalone') {
          // ─── SEPARADOR AUTÔNOMO (VS ou X isolado) ───
          const si = sep.index;
          if (si < 1 || si >= leaves.length - 1) return;

          homeTeam = cleanTeamName(leaves[si - 1]);
          awayTeam = cleanTeamName(leaves[si + 1]);

          // Liga: geralmente 2 posições antes do VS
          if (si >= 2 && !isNumericish(leaves[si - 2])) {
            league = leaves[si - 2];
          }

          // Limite superior: próximo separador ou +12 posições
          const nextSep = separators[idx + 1];
          const boundary = nextSep ? nextSep.index : Math.min(si + 12, leaves.length);

          // Coletar valores numéricos após o away team
          for (let i = si + 2; i < boundary; i++) {
            const t = leaves[i].trim();
            if (isNumericish(t)) {
              stats.push(t);
              if (stats.length >= 7) break; // no máximo 7 stats
            } else if (stats.length > 0) {
              // Parou de ser numérico — verificar se é início de próximo card
              if (isValidTeamName(t)) break;
            }
          }

          // Se temos poucos stats (< 3), pode ser um destaque em formato standalone X
          if (stats.length < 3) {
            // Procurar porcentagem perto
            for (let i = si + 2; i < Math.min(si + 6, leaves.length); i++) {
              const m = leaves[i].match(/^(\d+)%$/);
              if (m) { rate = parseFloat(m[1]); break; }
            }
            // Procurar info com "|"
            for (let i = si - 3; i <= si + 5 && i < leaves.length; i++) {
              if (i < 0) continue;
              if (leaves[i].includes('|')) {
                const parts = leaves[i].split('|');
                league = parts[0].trim();
                if (parts[1]) {
                  const dt = parts[1].trim().split(/\s+/);
                  dateStr = dt[0] || '';
                  timeStr = dt[1] || '';
                }
                break;
              }
            }
          }

        } else {
          // ─── SEPARADOR INLINE ("Team A x Team B") ───
          const si = sep.index;
          const matchLine = leaves[si];
          const sepMatch = matchLine.match(/\s+(x|×|vs)\s+/i);
          if (!sepMatch) return;

          const parts = matchLine.split(sepMatch[0]);
          homeTeam = cleanTeamName(parts[0]);
          awayTeam = cleanTeamName(parts.slice(1).join(' '));

          // Procurar info e porcentagem ao redor (+/- 5 posições)
          for (let i = si + 1; i < Math.min(si + 6, leaves.length); i++) {
            const t = leaves[i].trim();
            if (t.includes('|') && !league) {
              const infoParts = t.split('|');
              league = infoParts[0].trim();
              if (infoParts[1]) {
                const dt = infoParts[1].trim().split(/\s+/);
                dateStr = dt[0] || '';
                timeStr = dt[1] || '';
              }
            }
            const m = t.match(/^(\d+)%$/);
            if (m && rate === null) {
              rate = parseFloat(m[1]);
            }
          }
          // Backward search para league
          for (let i = si - 1; i >= Math.max(si - 4, 0); i--) {
            const t = leaves[i].trim();
            if (t.includes('|') && !league) {
              const infoParts = t.split('|');
              league = infoParts[0].trim();
              if (infoParts[1]) {
                const dt = infoParts[1].trim().split(/\s+/);
                dateStr = dt[0] || '';
                timeStr = dt[1] || '';
              }
              break;
            }
          }
        }

        // Validar times
        if (!isValidTeamName(homeTeam) || !isValidTeamName(awayTeam)) {
          console.log(`[TradePro v3] ⚠ Sep #${idx}: times inválidos — H:"${homeTeam}" A:"${awayTeam}"`);
          return;
        }

        // Classificar período
        const period = classifyPeriod(sep.index, sections, pagePeriods);
        const isHT = period === 'HT';

        // Montar o objeto de resultado
        const match = {
          home_team: homeTeam,
          away_team: awayTeam,
          league: league || null,
          date_str: dateStr || null,
          match_time: timeStr || null,
          // Taxas e médias do listing detalhado
          ht_avg: null, ht_limit_rate: null, home_ht_limit_rate: null,
          away_ht_limit_rate: null, ht_limit_avg: null,
          ft_avg: null, ft_limit_rate: null, home_ft_limit_rate: null,
          away_ft_limit_rate: null, ft_limit_avg: null,
          // Destaques
          is_top_ht: false, is_top_ft: false,
          top_ht_rate: null, top_ft_rate: null
        };

        if (stats.length >= 5) {
          // Temos dados detalhados (listing com métricas)
          const avg       = parseNum(stats[0]);
          const limitRate  = parseNum(stats[1]);
          const homeRate   = parseNum(stats[2]);
          const awayRate   = parseNum(stats[3]);
          const limitAvg   = parseNum(stats[4]);

          if (isHT) {
            match.ht_avg = avg;
            match.ht_limit_rate = limitRate;
            match.home_ht_limit_rate = homeRate;
            match.away_ht_limit_rate = awayRate;
            match.ht_limit_avg = limitAvg;
          } else {
            match.ft_avg = avg;
            match.ft_limit_rate = limitRate;
            match.home_ft_limit_rate = homeRate;
            match.away_ft_limit_rate = awayRate;
            match.ft_limit_avg = limitAvg;
          }
          console.log(`[TradePro v3] ✅ Detalhado #${idx}: ${homeTeam} vs ${awayTeam} [${period}] avg=${avg} rate=${limitRate}%`);
        } else if (rate !== null) {
          // Temos dados de destaque (TOP 10 com porcentagem)
          if (isHT) {
            match.is_top_ht = true;
            match.top_ht_rate = rate;
          } else {
            match.is_top_ft = true;
            match.top_ft_rate = rate;
          }
          console.log(`[TradePro v3] ✅ Destaque #${idx}: ${homeTeam} vs ${awayTeam} [${period}] rate=${rate}%`);
        } else {
          // Sem dados numéricos — ainda registrar o confronto
          console.log(`[TradePro v3] ⚠ Sep #${idx}: ${homeTeam} vs ${awayTeam} — sem stats/rate, registrando sem métricas.`);
        }

        results.push(match);
      } catch (err) {
        console.error(`[TradePro v3] Erro processando separador #${idx}:`, err);
      }
    });

    return results;
  }

  // ═══════════════════════════════════════════════════════════════════
  // HANDLERS DO PAINEL
  // ═══════════════════════════════════════════════════════════════════

  function handleScan() {
    const statusEl = document.getElementById('tradepro-scan-status');
    const syncBtn  = document.getElementById('tradepro-btn-sync');

    try {
      const rawResults = scanPage();

      // Mesclar duplicatas por confronto
      const combinedMap = new Map();
      rawResults.forEach(m => {
        const key = `${m.home_team}|||${m.away_team}`.toLowerCase();
        if (combinedMap.has(key)) {
          const ex = combinedMap.get(key);
          const mg = (nv, ov) => (nv !== null && nv !== undefined) ? nv : ov;
          combinedMap.set(key, {
            ...ex,
            league: m.league || ex.league,
            match_time: m.match_time || ex.match_time,
            date_str: m.date_str || ex.date_str,
            ht_avg: mg(m.ht_avg, ex.ht_avg),
            ht_limit_rate: mg(m.ht_limit_rate, ex.ht_limit_rate),
            home_ht_limit_rate: mg(m.home_ht_limit_rate, ex.home_ht_limit_rate),
            away_ht_limit_rate: mg(m.away_ht_limit_rate, ex.away_ht_limit_rate),
            ht_limit_avg: mg(m.ht_limit_avg, ex.ht_limit_avg),
            ft_avg: mg(m.ft_avg, ex.ft_avg),
            ft_limit_rate: mg(m.ft_limit_rate, ex.ft_limit_rate),
            home_ft_limit_rate: mg(m.home_ft_limit_rate, ex.home_ft_limit_rate),
            away_ft_limit_rate: mg(m.away_ft_limit_rate, ex.away_ft_limit_rate),
            ft_limit_avg: mg(m.ft_limit_avg, ex.ft_limit_avg),
            is_top_ht: m.is_top_ht || ex.is_top_ht,
            is_top_ft: m.is_top_ft || ex.is_top_ft,
            top_ht_rate: mg(m.top_ht_rate, ex.top_ht_rate),
            top_ft_rate: mg(m.top_ft_rate, ex.top_ft_rate)
          });
        } else {
          combinedMap.set(key, { ...m });
        }
      });

      scannedData = Array.from(combinedMap.values());
      console.log(`[TradePro v3] Total final: ${scannedData.length} jogos únicos.`, scannedData);

      if (scannedData.length > 0) {
        statusEl.innerHTML = `🟢 <b>Sucesso!</b> Encontrado(s) <b>${scannedData.length}</b> jogo(s) na página.<br><span style="font-size:0.72rem; color:#10b981; font-weight:700;">Pronto para sincronizar!</span>`;
        statusEl.style.color = '#f1f5f9';
        syncBtn.disabled = false;
        syncBtn.style.opacity = '1';
        syncBtn.style.cursor = 'pointer';
      } else {
        statusEl.innerHTML = '❌ Nenhum jogo detectado. Verifique se a página carregou completamente.<br><span style="font-size:0.7rem;color:#94a3b8;">Abra o console (F12) para diagnóstico detalhado.</span>';
        statusEl.style.color = '#ef4444';
        syncBtn.disabled = true;
        syncBtn.style.opacity = '0.4';
        syncBtn.style.cursor = 'not-allowed';
      }
    } catch (e) {
      console.error('[TradePro v3] Erro no scan:', e);
      statusEl.textContent = '❌ Erro interno durante o escaneamento. Veja o console.';
      statusEl.style.color = '#ef4444';
    }
  }

  async function handleSync() {
    const statusEl = document.getElementById('tradepro-scan-status');
    const syncBtn  = document.getElementById('tradepro-btn-sync');
    const targetDate = document.getElementById('tradepro-sync-date').value;

    if (!targetDate) {
      statusEl.textContent = '❌ Selecione uma data de referência!';
      statusEl.style.color = '#ef4444';
      return;
    }
    if (scannedData.length === 0) return;

    syncBtn.disabled = true;
    syncBtn.style.opacity = '0.4';
    syncBtn.textContent = '⏳ Sincronizando...';
    statusEl.innerHTML = '⚡ Consultando registros existentes no Supabase...';

    try {
      // 1. Buscar existentes para esta data
      const getUrl = `${SUPABASE_URL}/rest/v1/bestcorner_prelive_stats?date=eq.${targetDate}&select=*`;
      const fetchRes = await fetch(getUrl, {
        method: 'GET',
        headers: {
          'apikey': SUPABASE_KEY,
          'Authorization': `Bearer ${SUPABASE_KEY}`
        }
      });

      if (!fetchRes.ok) {
        const errText = await fetchRes.text();
        throw new Error(`Erro ao consultar banco: HTTP ${fetchRes.status} — ${errText}`);
      }

      const existingRows = await fetchRes.json();
      const existingMap = new Map();
      existingRows.forEach(row => {
        const key = `${row.home_team}|||${row.away_team}`.toLowerCase();
        existingMap.set(key, row);
      });
      console.log(`[TradePro v3] ${existingRows.length} registros existentes para ${targetDate}.`);

      // 2. Mesclar novos com existentes
      const mg = (nv, ov) => (nv !== null && nv !== undefined) ? nv : ((ov !== null && ov !== undefined) ? ov : null);

      const mergedList = scannedData.map(newItem => {
        const key = `${newItem.home_team}|||${newItem.away_team}`.toLowerCase();
        const old = existingMap.get(key) || {};

        return {
          date: targetDate,
          home_team: newItem.home_team,
          away_team: newItem.away_team,
          league: newItem.league || old.league || null,
          match_time: newItem.match_time || old.match_time || null,
          ht_avg: mg(newItem.ht_avg, old.ht_avg),
          ht_limit_rate: mg(newItem.ht_limit_rate, old.ht_limit_rate),
          home_ht_limit_rate: mg(newItem.home_ht_limit_rate, old.home_ht_limit_rate),
          away_ht_limit_rate: mg(newItem.away_ht_limit_rate, old.away_ht_limit_rate),
          ht_limit_avg: mg(newItem.ht_limit_avg, old.ht_limit_avg),
          ft_avg: mg(newItem.ft_avg, old.ft_avg),
          ft_limit_rate: mg(newItem.ft_limit_rate, old.ft_limit_rate),
          home_ft_limit_rate: mg(newItem.home_ft_limit_rate, old.home_ft_limit_rate),
          away_ft_limit_rate: mg(newItem.away_ft_limit_rate, old.away_ft_limit_rate),
          ft_limit_avg: mg(newItem.ft_limit_avg, old.ft_limit_avg),
          is_top_ht: newItem.is_top_ht || old.is_top_ht || false,
          is_top_ft: newItem.is_top_ft || old.is_top_ft || false,
          top_ht_rate: mg(newItem.top_ht_rate, old.top_ht_rate),
          top_ft_rate: mg(newItem.top_ft_rate, old.top_ft_rate)
        };
      });

      // 3. Upsert no Supabase
      const upsertUrl = `${SUPABASE_URL}/rest/v1/bestcorner_prelive_stats?on_conflict=date,home_team,away_team`;
      const upsertRes = await fetch(upsertUrl, {
        method: 'POST',
        headers: {
          'apikey': SUPABASE_KEY,
          'Authorization': `Bearer ${SUPABASE_KEY}`,
          'Content-Type': 'application/json',
          'Prefer': 'resolution=merge-duplicates'
        },
        body: JSON.stringify(mergedList)
      });

      if (!upsertRes.ok) {
        const errText = await upsertRes.text();
        throw new Error(`Erro ao salvar: HTTP ${upsertRes.status} — ${errText}`);
      }

      statusEl.innerHTML = `✅ <b>Sincronizado!</b><br>Foram enviados <b>${mergedList.length}</b> jogos para <b>${targetDate}</b>.`;
      statusEl.style.color = '#10b981';
      syncBtn.disabled = true;
      syncBtn.style.opacity = '0.4';
    } catch (e) {
      console.error('[TradePro v3] Erro na sincronização:', e);
      statusEl.innerHTML = `❌ <b>Erro:</b><br>${e.message || e}`;
      statusEl.style.color = '#ef4444';
      syncBtn.disabled = false;
      syncBtn.style.opacity = '1';
    } finally {
      syncBtn.textContent = '🟢 Sincronizar com TradePro';
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  // INICIALIZAÇÃO
  // ═══════════════════════════════════════════════════════════════════
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', injectPanel);
  } else {
    injectPanel();
  }
})();
